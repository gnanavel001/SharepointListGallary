/* tslint:disable */
require("./Dlaccrodian.module.css");
const styles = {
  accordion: 'accordion_1d0f7a37',
  header: 'header_1d0f7a37',
  search: 'search_1d0f7a37',
  searchIcon: 'searchIcon_1d0f7a37',
  accordianContent: 'accordianContent_1d0f7a37',
  card: 'card_1d0f7a37',
  open: 'open_1d0f7a37',
  vewbutton: 'vewbutton_1d0f7a37'
};

export default styles;
/* tslint:enable */