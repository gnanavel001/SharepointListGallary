/// <reference types="react" />
import { IData } from "./types";
declare function Card({ content }: Readonly<{
    content: IData[];
}>): JSX.Element;
export default Card;
//# sourceMappingURL=Card.d.ts.map