import * as React from 'react';
import type { IDlaccrodianProps } from './IDlaccrodianProps';
import "@pnp/sp/lists";
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/fields";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
declare const Dlaccrodian: React.FunctionComponent<IDlaccrodianProps>;
export default Dlaccrodian;
//# sourceMappingURL=Dlaccrodian.d.ts.map