declare const styles: {
    accordion: string;
    header: string;
    search: string;
    searchIcon: string;
    accordianContent: string;
    card: string;
    open: string;
    vewbutton: string;
};
export default styles;
//# sourceMappingURL=Dlaccrodian.module.scss.d.ts.map