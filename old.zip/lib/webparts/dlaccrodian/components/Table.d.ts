/// <reference types="react" />
import { IData } from "./types";
declare function Table({ content }: Readonly<{
    content: IData[];
}>): JSX.Element;
export default Table;
//# sourceMappingURL=Table.d.ts.map