import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IDlaccrodianProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: WebPartContext;
    listId: string;
    listAccordianColumns: any;
    columnsToShow: any;
}
//# sourceMappingURL=IDlaccrodianProps.d.ts.map