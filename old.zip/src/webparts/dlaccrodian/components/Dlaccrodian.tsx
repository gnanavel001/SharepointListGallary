import * as React from 'react';
import { useEffect, useState, useRef, SyntheticEvent, useCallback } from 'react';
import type { IDlaccrodianProps } from './IDlaccrodianProps';
import styles from './Dlaccrodian.module.scss';
import "@pnp/sp/lists";
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/fields";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
import { spfi, SPFx } from "@pnp/sp";
import * as _ from 'lodash';
import { IData } from './types';
import Accordian from './Accordian';
import Card from "./Card";

const Dlaccrodian: React.FunctionComponent<IDlaccrodianProps> = (props) => {
  const [items, setitems] = useState([]);
  const [accordiansOpened, setAccordiansOpened] = useState<string[]>([]);
  const imageref: any = useRef();
  const sp = spfi().using(SPFx(props.context));
  //data from sp list
  async function getlistitems() {
    let response: any = await sp.web.lists.getById(props.listId).items.select("*", "FileRef", "FileLeafRef", "EncodedAbsUrl")();
    console.log(response)
    setitems(response);
  }

  async function inputOnchangeGetListItems(inputtest: string) {
    let filterQuery = `<View><Query> <Where>`;
    for (var i = 0; i < props.listAccordianColumns; i++) {
      filterQuery += `<And>`
    }
    console.log("columns to show", props.columnsToShow, filterQuery);
    if (inputtest.length > 0) {
      imageref.current.style.display = "none";
    } else {
      imageref.current.style.display = "initial";
    }
    let result: any = await sp.web.lists.getById(props.listId).items.filter("substringof('" + inputtest + "',FileLeafRef)").select("*", "FileRef", "FileLeafRef", "EncodedAbsUrl")();

    console.log(result);

    setitems(result);
  }



  const groupBy = (data: IData[], key: string) => {
    return data.reduce((acc, item) => {
      const groupKey = item[key as keyof IData] as string;

      if (!acc[groupKey]) {
        acc[groupKey] = { item: [], uniqueKey: "" };
      }

      acc[groupKey].item.push(item);
      acc[groupKey].uniqueKey = item.GUID;

      return acc;
    }, {} as Record<string, { item: IData[]; uniqueKey: string }>);
  };

  const handleToggle = useCallback(
    (e: SyntheticEvent<HTMLDetailsElement>, uniqueKey: string) => {
      if (e.currentTarget.open) {
        setAccordiansOpened((prev) => [...prev, uniqueKey]);
      } else {
        setAccordiansOpened(accordiansOpened.filter((e) => e !== uniqueKey));
      }
    },
    [accordiansOpened]
  );

  const renderAccordian = useCallback(
    (data: IData[], keys: string[], level = 0) => {
      if (level >= keys.length) {
        return <Card content={data} />;
      }

      const groupedData = groupBy(data, keys[level]);

      return Object.keys(groupedData).map((key) => {
        const uniqueKey = groupedData[key].uniqueKey + " " + key;

        return key !== "undefined" ? (
          <Accordian
            key={uniqueKey}
            title={`${key} (${groupedData[key].item.length})`}
            isOpen={accordiansOpened.includes(uniqueKey)}
            onToggle={(e) => handleToggle(e, uniqueKey)}
          >
            {renderAccordian(groupedData[key].item, keys, level + 1)}
          </Accordian>
        ) : (
          <Card content={data} />
        );
      });
    },
    [accordiansOpened, handleToggle]
  );
  useEffect(() => {
    getlistitems();
  }, [])
  return <>
    {items && <div className={styles.accordion}>
      <div className={styles.header}>
        <div className={styles.search}>
          <input type="text" name="" id="" placeholder="Search" onChange={(e) => {
            if (e.target.value.length > 0) {
              inputOnchangeGetListItems(e.target.value)
            } else {
              getlistitems();
            }
          }} />
          <img src={require('../assets/search.svg')} ref={imageref}
            alt="" width={20} height={20} className={styles.searchIcon} />
        </div>
      </div>
      <div className={styles.accordianContent}>
        {renderAccordian(items as IData[], props.listAccordianColumns)}
      </div>

    </div>}

  </>
}
export default Dlaccrodian;