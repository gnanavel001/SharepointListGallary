import * as React from 'react';
import { SyntheticEvent } from "react";
declare function Accordian({ title, isOpen, onToggle, children, }: Readonly<{
    title: string;
    isOpen: boolean;
    onToggle: (e: SyntheticEvent<HTMLDetailsElement>) => void;
    children: React.ReactNode;
}>): JSX.Element;
export default Accordian;
//# sourceMappingURL=Accordian.d.ts.map